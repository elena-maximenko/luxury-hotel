CREATE TRIGGER NumberInsertChecker
BEFORE INSERT ON rooms
FOR EACH ROW
  BEGIN
IF(NEW.RoomNumber < 0) THEN
SET NEW.RoomNumber = ABS(NEW.RoomNumber) ; 
END IF ; 
IF(NEW.Price < 0) THEN
SET NEW.Price = ABS(NEW.Price) ; 
END IF ; 
END;
